package com.dcc.android

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.*
import org.apache.commons.net.ftp.FTP
import org.apache.commons.net.ftp.FTPClient
import org.apache.commons.net.telnet.TelnetClient
import java.io.InputStream
import java.io.OutputStream

class MainActivity : AppCompatActivity() {

    private lateinit var etHost: EditText
    private lateinit var etUser: EditText
    private lateinit var etPass: EditText
    private lateinit var tvConsole: TextView
    private lateinit var scrollLog: ScrollView
    private lateinit var etCommand: EditText
    private lateinit var layoutTerminal: LinearLayout
    private lateinit var layoutFtp: LinearLayout
    private lateinit var lvFtpFiles: ListView
    private lateinit var tvFtpPath: TextView

    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var telnetClient: TelnetClient? = null
    private var telnetOut: OutputStream? = null
    private var currentRemoteDir = "/tmp"
    private val fileList = mutableListOf<String>()
    private lateinit var fileAdapter: ArrayAdapter<String>

    private val filePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { uploadFileToReceiver(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etHost = findViewById(R.id.etHost)
        etUser = findViewById(R.id.etUser)
        etPass = findViewById(R.id.etPass)
        tvConsole = findViewById(R.id.tvConsole)
        scrollLog = findViewById(R.id.scrollLog)
        etCommand = findViewById(R.id.etCommand)
        layoutTerminal = findViewById(R.id.layoutTerminal)
        layoutFtp = findViewById(R.id.layoutFtp)
        lvFtpFiles = findViewById(R.id.lvFtpFiles)
        tvFtpPath = findViewById(R.id.tvFtpPath)

        fileAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, fileList)
        lvFtpFiles.adapter = fileAdapter

        findViewById<Button>(R.id.btnConnect).setOnClickListener { connectTelnetAndFtp() }
        findViewById<Button>(R.id.btnTabTerminal).setOnClickListener {
            layoutTerminal.visibility = View.VISIBLE
            layoutFtp.visibility = View.GONE
        }
        findViewById<Button>(R.id.btnTabFtp).setOnClickListener {
            layoutTerminal.visibility = View.GONE
            layoutFtp.visibility = View.VISIBLE
            listFtpDirectory(currentRemoteDir)
        }

        findViewById<Button>(R.id.btnSend).setOnClickListener {
            val cmd = etCommand.text.toString()
            if (cmd.isNotBlank()) {
                sendTelnetCommand(cmd)
                etCommand.text.clear()
            }
        }

        // DCC Quick Action Macros
        findViewById<Button>(R.id.btnInstallIpk).setOnClickListener {
            sendTelnetCommand("opkg install --force-overwrite /tmp/*.ipk")
        }
        findViewById<Button>(R.id.btnInstallTpk).setOnClickListener {
            sendTelnetCommand("tar -xzf /tmp/*.tpk -C / && sync")
        }
        findViewById<Button>(R.id.btnRestartGui).setOnClickListener {
            sendTelnetCommand("killall -9 enigma2")
        }
        findViewById<Button>(R.id.btnReboot).setOnClickListener {
            sendTelnetCommand("reboot")
        }

        findViewById<Button>(R.id.btnUploadTmp).setOnClickListener {
            filePicker.launch("*/*")
        }
        findViewById<Button>(R.id.btnRefreshFtp).setOnClickListener {
            listFtpDirectory(currentRemoteDir)
        }

        lvFtpFiles.setOnItemClickListener { _, _, position, _ ->
            val selected = fileList[position]
            if (selected == "..") {
                currentRemoteDir = currentRemoteDir.substringBeforeLast('/').ifEmpty { "/" }
                listFtpDirectory(currentRemoteDir)
            } else if (selected.startsWith("[DIR] ")) {
                val dirName = selected.removePrefix("[DIR] ")
                currentRemoteDir = if (currentRemoteDir == "/") "/$dirName" else "$currentRemoteDir/$dirName"
                listFtpDirectory(currentRemoteDir)
            }
        }
    }

    private fun appendLog(text: String) {
        tvConsole.append(text)
        scrollLog.post { scrollLog.fullScroll(View.FOCUS_DOWN) }
    }

    private fun connectTelnetAndFtp() {
        val host = etHost.text.toString().trim()
        val user = etUser.text.toString().trim()
        val pass = etPass.text.toString()

        appendLog("\nConnecting to $host...\n")
        scope.launch(Dispatchers.IO) {
            try {
                telnetClient?.disconnect()
                val client = TelnetClient()
                client.connectTimeout = 5000
                client.connect(host, 23)
                telnetClient = client
                telnetOut = client.outputStream

                val input: InputStream = client.inputStream
                val buffer = ByteArray(1024)

                // Auto-login sequence
                delay(500)
                if (user.isNotEmpty()) {
                    telnetOut?.write("$user\n".toByteArray())
                    telnetOut?.flush()
                    delay(400)
                }
                if (pass.isNotEmpty()) {
                    telnetOut?.write("$pass\n".toByteArray())
                    telnetOut?.flush()
                }

                while (client.isConnected) {
                    val read = input.read(buffer)
                    if (read == -1) break
                    val chunk = String(buffer, 0, read)
                    withContext(Dispatchers.Main) { appendLog(chunk) }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    appendLog("\n[Telnet Error] ${e.message}\n")
                }
            }
        }
        listFtpDirectory(currentRemoteDir)
    }

    private fun sendTelnetCommand(cmd: String) {
        scope.launch(Dispatchers.IO) {
            try {
                telnetOut?.write("$cmd\n".toByteArray())
                telnetOut?.flush()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { appendLog("\n[Send Error] ${e.message}\n") }
            }
        }
    }

    private fun listFtpDirectory(path: String) {
        val host = etHost.text.toString().trim()
        val user = etUser.text.toString().trim()
        val pass = etPass.text.toString()

        scope.launch(Dispatchers.IO) {
            val ftp = FTPClient()
            try {
                ftp.connectTimeout = 5000
                ftp.connect(host, 21)
                ftp.login(user, pass)
                ftp.enterLocalPassiveMode()
                ftp.changeWorkingDirectory(path)

                val files = ftp.listFiles()
                val items = mutableListOf("..")
                for (f in files) {
                    if (f.name == "." || f.name == "..") continue
                    if (f.isDirectory) items.add("[DIR] ${f.name}")
                    else items.add("${f.name} (${f.size / 1024} KB)")
                }

                withContext(Dispatchers.Main) {
                    tvFtpPath.text = "Remote Path: $path"
                    fileList.clear()
                    fileList.addAll(items)
                    fileAdapter.notifyDataSetChanged()
                }
                ftp.logout()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    appendLog("\n[FTP Error] ${e.message}\n")
                }
            } finally {
                if (ftp.isConnected) ftp.disconnect()
            }
        }
    }

    private fun uploadFileToReceiver(uri: Uri) {
        val host = etHost.text.toString().trim()
        val user = etUser.text.toString().trim()
        val pass = etPass.text.toString()
        val fileName = getFileName(uri) ?: "upload.bin"

        appendLog("\nUploading $fileName to $currentRemoteDir...\n")
        scope.launch(Dispatchers.IO) {
            val ftp = FTPClient()
            try {
                ftp.connect(host, 21)
                ftp.login(user, pass)
                ftp.enterLocalPassiveMode()
                ftp.setFileType(FTP.BINARY_FILE_TYPE)
                ftp.changeWorkingDirectory(currentRemoteDir)

                contentResolver.openInputStream(uri)?.use { input ->
                    val success = ftp.storeFile(fileName, input)
                    withContext(Dispatchers.Main) {
                        if (success) {
                            appendLog("Uploaded $fileName successfully!\n")
                            listFtpDirectory(currentRemoteDir)
                        } else {
                            appendLog("FTP upload failed: ${ftp.replyString}\n")
                        }
                    }
                }
                ftp.logout()
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { appendLog("[Upload Error] ${e.message}\n") }
            } finally {
                if (ftp.isConnected) ftp.disconnect()
            }
        }
    }

    private fun getFileName(uri: Uri): String? {
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (cursor.moveToFirst() && idx >= 0) return cursor.getString(idx)
        }
        return uri.lastPathSegment
    }

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
        try { telnetClient?.disconnect() } catch (_: Exception) {}
    }
}
