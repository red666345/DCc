# DCC Android (Dreambox Control Center for Android)

A lightweight Android companion app combining **Telnet** and **FTP** for Enigma2 and TitanNit receivers.

## Features
- **Telnet Client:** Live terminal output with auto-login (`root` + password).
- **DCC Quick Macros:** One-tap buttons to install `/tmp/*.ipk`, extract `/tmp/*.tpk`, restart Enigma2 GUI, or reboot the receiver.
- **FTP Browser & Uploader:** Browse receiver directories (`/tmp`, `/etc`, `/var`, etc.) and upload local `.ipk`, `.tpk`, or channel/config files directly from your phone.

## How to Build the APK
1. Install **Android Studio** on your PC.
2. Open the extracted `DCCAndroid` folder in Android Studio.
3. Let Gradle sync and download `commons-net` automatically.
4. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)** to generate `app-debug.apk` for your phone.
